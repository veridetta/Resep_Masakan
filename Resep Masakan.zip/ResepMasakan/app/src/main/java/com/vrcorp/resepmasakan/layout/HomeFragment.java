package com.vrcorp.resepmasakan.layout;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SearchView;


import com.machinepublishers.jbrowserdriver.JBrowserDriver;
import com.machinepublishers.jbrowserdriver.Settings;
import com.machinepublishers.jbrowserdriver.Timezone;
import com.machinepublishers.jbrowserdriver.UserAgent;
import com.vrcorp.resepmasakan.R;
import com.vrcorp.resepmasakan.adapter.HomeAdapter;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;


import java.util.ArrayList;

import static com.android.volley.VolleyLog.TAG;


public class HomeFragment extends Fragment {
    ProgressDialog dialog;
    SharedPreferences sharedpreferences;
    RecyclerView order_list;
    View view;
    SearchView cari;
    SwipeRefreshLayout refresh;
    Document mBlogDocument  = null, cardDoc = null;
    private ArrayList<String> card_gambar = new ArrayList<>();
    private ArrayList<String> card_kategori = new ArrayList<String>();
    private ArrayList<String> card_judul = new ArrayList<>();
    private ArrayList<String> card_url = new ArrayList<>();
    public HomeFragment() {
        // Required empty public constructor
    }


    public static HomeFragment newInstance(String param1, String param2) {
        HomeFragment fragment = new HomeFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_home, container, false);
        //noData = view.findViewById(R.id.no_data);
        sharedpreferences = getActivity().getSharedPreferences("resepMakanan", Context.MODE_PRIVATE);
        //string_id = sharedpreferences.getString("id", null);
        cari = view.findViewById(R.id.cari_input);
        refresh = view.findViewById(R.id.swiperefresh);
        cari.setQueryHint("Cari Konjugasi");
        cari.onActionViewExpanded();
        cari.setIconified(true);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                cari.clearFocus();
            }
        }, 300);
        cari.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {

                return false;
            }
        });
        dialog = new ProgressDialog(getActivity());
        dialog.setCancelable(false);
        dialog.setMessage("Memuat data ....");
        dialog.show();
        refresh.setOnRefreshListener(
                new SwipeRefreshLayout.OnRefreshListener() {
                    @Override
                    public void onRefresh() {
                        new CardGet().execute();
                        dialog.show();
                    }
                }
        );
        new CardGet().execute();
        dialog.show();
        return view;
    }
    private class CardGet extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... params) {
            // NO CHANGES TO UI TO BE DONE HERE
            String url = "https://resepdemo.blogspot.com/";
            JBrowserDriver driver = new JBrowserDriver(Settings.builder()
                    .userAgent(UserAgent.CHROME).build());

            // This will block for the page load and any
            // associated AJAX requests
            driver.get("http://example.com");

            // You can get status code unlike other Selenium drivers.
            // It blocks for AJAX requests and page loads after clicks
            // and keyboard events.
            System.out.println(driver.getStatusCode());

            // Returns the page source in its current state, including
            // any DOM updates that occurred after page load
            System.out.println(driver.getPageSource());

            // Close the browser. Allows this thread to terminate.

            // JSoup parsing part
            //Document document = Jsoup.parse(loadedPage);
            //Elements elements = document.select("#nav-console span.data");

            //cardDoc  = Jsoup.connect(url).get();
            Document mBlogPagination = Jsoup.parse(driver.getPageSource());;
            driver.quit();

            Log.d(TAG, "doInBackground: "+mBlogPagination);
            // Using Elements to get the Meta data
            Elements mElementDataSize = mBlogPagination.select("div[class=date-posts] div[class=post-outer]");
            // Locate the content attribute
            int mElementSize = mElementDataSize.size();
            for (int i = 0; i < mElementSize; i++) {
                //Judul
                Elements ElemenJudul = mElementDataSize.select("h3[class=post-title entry-title]").eq(i);
                String Nama= ElemenJudul.text();
                //gambar
                Elements elGambar = mElementDataSize.select("div[class=post-body entry-content]").eq(i);
                String gambara = elGambar.select("img").eq(0).attr("src");
                Elements elKat = mElementDataSize.select("div[class=post-footer-line post-footer-line-2] span").eq(i);
                String ket = elKat.select("a").eq(0).text().trim();
                String urlPosting = ElemenJudul.select("a").eq(0).attr("src");
                //STATUS
                Elements elKata = mElementDataSize.select("p.fbquote").eq(i);
                String kata = elKata.text().trim();
                card_gambar.add(gambara);
                card_kategori.add(ket);
                card_judul.add(Nama);
                card_url.add(urlPosting);
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            //This is where we update the UI with the acquired data
            // Set description into TextView
            Log.d(TAG, "onPostExecute: "+result);
            RecyclerView mRecyclerView = (RecyclerView) getActivity().findViewById(R.id.rc_home);
            HomeAdapter mDataAdapter = new HomeAdapter( card_judul, card_kategori, card_gambar, card_url);
            RecyclerView.LayoutManager mLayoutManager = new GridLayoutManager(getActivity().getApplicationContext(),1);
            mRecyclerView.setLayoutManager(mLayoutManager);
            mRecyclerView.setAdapter(mDataAdapter);
            dialog.dismiss();
        }
    }
}